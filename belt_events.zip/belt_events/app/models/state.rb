class State < ActiveRecord::Base
end
