require 'rails_helper'

RSpec.describe JoinsController, type: :controller do

end
